FSTV — Projet source Android

Ce projet crée une application Android simple qui ouvre https://fstv.rest/ dans une WebView, sans barre d'adresse.
Internet est nécessaire. Le nom et l'icône sont des valeurs provisoires.

COMPILER L'APK AVEC ANDROID STUDIO
1. Installe Android Studio depuis https://developer.android.com/studio sur un ordinateur Windows, Mac ou Linux.
2. Décompresse FSTVAndroid.zip.
3. Dans Android Studio, choisis Open puis le dossier FSTVAndroid décompressé.
4. Accepte la synchronisation Gradle et l'installation des composants Android SDK proposés.
5. Pour tester sur un téléphone : active les Options développeur puis le Débogage USB, connecte le téléphone, puis clique sur Run.
6. Pour générer un APK : menu Build > Build Bundle(s) / APK(s) > Build APK(s).
7. À la fin, clique sur locate dans la notification Android Studio. Le fichier se trouve généralement dans app/build/outputs/apk/debug/app-debug.apk.
8. Copie l'APK sur ton téléphone et ouvre-le pour l'installer. Android peut demander d'autoriser l'installation depuis cette source.

LIMITES À CONNAÎTRE
- Le projet source n'est pas lui-même un APK compilé.
- Les téléchargements, connexions, DRM, notifications, paiements ou lecteurs vidéo particuliers peuvent demander des adaptations selon le fonctionnement réel de fstv.rest.
- N'installe l'APK que sur tes propres appareils ou ceux des personnes qui l'ont demandé.
